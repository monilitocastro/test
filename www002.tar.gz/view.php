<!DOCTYPE html>

<?php
class View
{
    private $model;
    private $controller;
 
    public function __construct($controller,$model) {
        $this->controller = $controller;
        $this->model = $model;
    }
 
    public function output() {
        return '<p><a href="mvc.php?action=clicked">' . $this->model->string . "</a></p>";
    }
    public function showLogo(){
     return "<img src=\"logo.png\"></img>";
    }
    public function showContentIFrame(){
     return "<iframe src=\"Authenticate/\" name=\"ContentIFrame\">"."</iframe>";
    }
    public function showTitle(){
     return "LifeThread Electronic Medical Record Software";
    }
    public function showTemplate(){
     return "<html>". $this->showPreBody() . $this->showBody() . "</html>";
    }
    public function showPreBody(){
     return "<head>
	 <meta http-equiv=\"content-type\" content=\"text/html; charset=utf-8\">
	 <link rel=\"stylesheet\" type=\"text/css\" href=\"blended_layout.css\">
	 <title>".$this->showTitle()."</title>
	 <meta name=\"description\" content=\"Write some words to describe your html page\">
         </head>";
    }
    public function showBody(){
     return "<body>" . "<div class=\"blended_grid\">". $this->showPageHeader(). $this->showPageLeftMenu(). $this->showPageContent(). $this->showPageFooter() ."</div>" . "</body>";
    }
    public function showPageHeader(){
     return "<div class=\"pageHeader\">" . $this->showLogo() . "</div>";
    }
    public function showPageLeftMenu(){
     return "<div class=\"pageLeftMenu\">
	    <ul>
   <li><a href=\"#elem1\">Elem1</a></li>
   <li><a href=\"#elem2\">Elem2</a></li>
   <li><a href=\"#elem3\">Elem3</a></li>
   <li><a href=\"#elem4\">Elem4</a></li>
  </ul>" ."</div>";
    }
    public function showPageContent(){
     return "<div class=\"pageContent\">".$this->showContentIFrame()."</div>";
    }
    public function showPageFooter(){
     return "<div class=\"pageFooter\">"."</div>";
    }
}
?>
<!--
<head>
	 <meta http-equiv="content-type" content="text/html; charset=utf-8">
	 <link rel="stylesheet" type="text/css" href="blended_layout.css">
	 <title>Page Title</title>
	 <meta name="description" content="Write some words to describe your html page">
</head>
<body>
<div class="blended_grid">
	  <div class="pageHeader">
	  </div>
	  <div class="pageLeftMenu">
	    <ul>
   <li><a href="#home">Home</a></li>
   <li><a href="#news">News</a></li>
   <li><a href="#contact">Contact</a></li>
   <li><a href="#about">About</a></li>
  </ul>
	  </div>
	  <div class="pageContent">
	  </div>
	  <div class="pageFooter">
	  </div>
</div>
</body>
</html>
-->
