<?php
class BaseUser{

 function Authenticate(){}
 function SignUpNewUser(){}
 function ScheduleAppointment(){}
 function CancelAppointment(){}
 function PrescribeMedication(){}
 function WritePhysiciansExam(){}
 function CreateDisease(){}
 function ModifyDiseaseThread(){/**Modifies the symptom code*/}
 function ViewMedicalRecord(){}
 function ViewPrescription(){}
 function ViewAccountBalance(){}
 function MakePayment(){}
 function ScheduleLabTest(){}
 function ViewLabHistory(){}
 function CreateSpecialistReferral(){}
 function UpdateAccountInformation(){}
 function CreateEmergencyFirstContact(){}
 function WriteNursesNotes(){}
}

?>
