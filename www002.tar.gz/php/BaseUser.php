<?php
class BaseUser{
 /**
   BaseUser is a class used by the classes Model, View, but not Controller.
   Model class uses BaseUser to store the name of sidebar buttons.
   View class uses BaseUser to find which buttons to show using the attribute vector.
   Controller doesn't use BaseUser.
   BaseUser has an attribute vector which correspond to particular use case methods.
   This attribute vector should be based on a Authentication state.
   The Authentication state ultimately must lead to the identification of user types.
   User types are Patient, Nurse, Nurse Practitioner, Physician, Specialist, Admin, EMT, Technician.
   These user types can have other states that precede it.
   All states which double as user type are preceded by unknown-user state.
   BaseUser has methods for each user type to define attribute vectors and names of buttons.
   Each use case method have both m or v character preceding the name to denote use by Model or View class.
   There is only one Controller behavior from authenticate to iframe of content panel.
   
 */
 public static $attributes;
 function __construct($type="Unknown"){
  if(strcmp($type, "Unknown")==0){
   $attributes = array(
     "Authenticate" => 1,
     "Logout"       => 0,
     "Sign Up New User" => 1,
     "Schedule Appointment" => 0,
     "Cancel Appointment" => 0,
     "Prescribe Medication" => 0,
     "Write Physicians Exam" => 0,
     "Create Disease" => 0,
     "Modify Disease Thread" => 0,
     "View Medical Record" => 0,
     "View Prescription" => 0,
     "View Account Balance" => 0,
     "Make Payment" => 0,
     "Schedule Lab Test" => 0,
     "View Lab History" => 0,
     "Create Specialist Referral" => 0,
     "Update Account Information" => 0,
     "Create Emergency First Contact" => 0,
     "Write Nurses Notes" => 0
   );
  }
  elseif(strcmp($type, "Patient")==0){
   $attributes = array(
     "Authenticate" => 0,
     "Logout"       => 1,
     "Sign Up New User" => 1,
     "Schedule Appointment" => 1,
     "Cancel Appointment" => 1,
     "Prescribe Medication" => 0,
     "Write Physicians Exam" => 0,
     "Create Disease" => 0,
     "Modify Disease Thread" => 0,
     "View Medical Record" => 0,
     "View Prescription" => 1,
     "View Account Balance" => 1,
     "Make Payment" => 0,
     "Schedule Lab Test" => 0,
     "View Lab History" => 0,
     "Create Specialist Referral" => 0,
     "Update Account Information" => 1,
     "Create Emergency FirstContact" => 0,
     "Write Nurses Notes" => 0
   );
  }
  elseif(strcmp($type, "Nurse")==0){
    $attributes = array(
     "Authenticate" => 0,
     "Logout"       => 1,
     "Sign Up New User" => 1,
     "Schedule Appointment" => 1,
     "Cancel Appointment" => 1,
     "Prescribe Medication" => 0,
     "Write Physicians Exam" => 0,
     "Create Disease" => 0,
     "Modify Disease Thread" => 0,
     "View Medical Record" => 1,
     "View Prescription" => 1,
     "View Account Balance" => 0,
     "Make Payment" => 0,
     "Schedule Lab Test" => 0,
     "View Lab History" => 1,
     "Create Specialist Referral" => 0,
     "Update Account Information" => 0,
     "Create Emergency First Contact" => 0,
     "Write Nurses Notes" => 1
   );
  }
  elseif(strcmp($type, "Nurse Practitioner")==0){
    $attributes = array(
     "Authenticate" => 0,
     "Logout"       => 1,
     "Sign Up New User" => 1,
     "Schedule Appointment" => 1,
     "Cancel Appointment" => 1,
     "Prescribe Medication" => 1,
     "Write Physicians Exam" => 1,
     "Create Disease" => 1,
     "Modify Disease Thread" => 1,
     "View Medical Record" => 1,
     "View Prescription" => 1,
     "View Account Balance" => 0,
     "Make Payment" => 0,
     "Schedule LabTest" => 1,
     "View Lab History" => 1,
     "Create Specialist Referral" => 1,
     "Update Account Information" => 0,
     "Create Emergency First Contact" => 0,
     "Write Nurses Notes" => 0
   );
   }
  elseif(strcmp($type, "Physician")==0){ 
    /*Keep in synch with Nurse Practitioner*/
    $attributes = array(
     "Authenticate" => 0,
     "Logout"       => 1,
     "Sign Up New User" => 1,
     "Schedule Appointment" => 1,
     "Cancel Appointment" => 1,
     "Prescribe Medication" => 1,
     "Write Physicians Exam" => 1,
     "Create Disease" => 1,
     "Modify Disease Thread" => 1,
     "View Medical Record" => 1,
     "View Prescription" => 1,
     "View AccountBalance" => 0,
     "Make Payment" => 0,
     "Schedule Lab Test" => 1,
     "View Lab History" => 1,
     "Create Specialist Referral" => 1,
     "Update Account Information" => 0,
     "Create Emergency First Contact" => 0,
     "Write Nurses Notes" => 0
   );
  }
  elseif(strcmp($type, "Specialist")==0){
    $attributes = array(
     "Authenticate" => 0,
     "Logout"       => 1,
     "Sign Up New User" => 0,
     "Schedule Appointment" => 1,
     "Cancel Appointment" => 1,
     "Prescribe Medication" => 1,
     "Write Physicians Exam" => 0,
     "Create Disease" => 1,
     "Modify Disease Thread" => 1,
     "View Medical Record" => 0,
     "View Prescription" => 1,
     "View Account Balance" => 0,
     "Make Payment" => 0,
     "Schedule Lab Test" => 1,
     "View Lab History" => 1,
     "Create Specialist Referral" => 1,
     "Update Account Information" => 0,
     "Create Emergency First Contact" => 0,
     "Write Nurses Notes" => 0
   );
  }
  elseif(strcmp($type, "Admin")==0){
    $attributes = array(
     "Authenticate" => 0,
     "Logout"       => 1,
     "Sign Up New User" => 1,
     "Schedule Appointment" => 1,
     "Cancel Appointment" => 1,
     "Prescribe Medication" => 0,
     "Write Physicians Exam" => 0,
     "Create Disease" => 0,
     "Modify Disease Thread" => 0,
     "View Medical Record" => 0,
     "View Prescription" => 0,
     "View Account Balance" => 1,
     "Make Payment" => 1,
     "Schedule Lab Test" => 0,
     "View Lab History" => 0,
     "Create Specialist Referral" => 0,
     "Update Account Information" => 1,
     "Create Emergency First Contact" => 0,
     "Write Nurses Notes" => 0
   );
  }
  elseif(strcmp($type, "EMT")==0){
    $attributes = array(
     "Authenticate" => 0,
     "Logout"       => 1,
     "Sign Up New User" => 0,
     "Schedule Appointment" => 0,
     "Cancel Appointment" => 0,
     "Prescribe Medication" => 0,
     "Write Physicians Exam" => 0,
     "Create Disease" => 0,
     "Modify Disease Thread" => 0,
     "View Medical Record" => 1,
     "View Prescription" => 1,
     "View Account Balance" => 0,
     "Make Payment" => 0,
     "Schedule Lab Test" => 0,
     "View Lab History" => 0,
     "Create Specialist Referral" => 0,
     "Update Account Information" => 0,
     "Create Emergency First Contact" => 1,
     "Write Nurses Notes" => 0
   );
  }
  elseif(strcmp($type, "Technician")==0){
    $attributes = array(
     "Authenticate" => 0,
     "Logout"       => 1,
     "Sign Up New User" => 0,
     "Schedule Appointment" => 0,
     "Cancel Appointment" => 0,
     "Prescribe Medication" => 0,
     "Write Physicians Exam" => 0,
     "Create Disease" => 0,
     "Modify Disease Thread" => 0,
     "View Medical Record" => 0,
     "View Prescription" => 0,
     "View Account Balance" => 0,
     "Make Payment" => 0,
     "Schedule Lab Test" => 1,
     "View Lab History" => 1,
     "Create Specialist Referral" => 0,
     "Update Account Information" => 0,
     "Create Emergency First Contact" => 0,
     "Write Nurses Notes" => 0
   );
  }
  else{
    print "ERROR: UKNOWN USER TYPE IN CONSTRUCTION OF BaseUser.";
  }
 }
 

 private function mAuthenticate(){}
 private function mSignUpNewUser(){}
 private function mScheduleAppointment(){}
 private function mCancelAppointment(){}
 private function mPrescribeMedication(){}
 private function mWritePhysiciansExam(){}
 private function mCreateDisease(){}
 private function mModifyDiseaseThread(){/**Modifies the symptom code*/}
 private function mViewMedicalRecord(){}
 private function mViewPrescription(){}
 private function mViewAccountBalance(){}
 private function mMakePayment(){}
 private function mScheduleLabTest(){}
 private function mViewLabHistory(){}
 private function mCreateSpecialistReferral(){}
 private function mUpdateAccountInformation(){}
 private function mCreateEmergencyFirstContact(){}
 private function mWriteNursesNotes(){}
 
 private function vAuthenticate(){}
 private function vSignUpNewUser(){}
 private function vScheduleAppointment(){}
 private function vCancelAppointment(){}
 private function vPrescribeMedication(){}
 private function vWritePhysiciansExam(){}
 private function vCreateDisease(){}
 private function vModifyDiseaseThread(){/**Modifies the symptom code*/}
 private function vViewMedicalRecord(){}
 private function vViewPrescription(){}
 private function vViewAccountBalance(){}
 private function vMakePayment(){}
 private function vScheduleLabTest(){}
 private function vViewLabHistory(){}
 private function vCreateSpecialistReferral(){}
 private function vUpdateAccountInformation(){}
 private function vCreateEmergencyFirstContact(){}
 private function vWriteNursesNotes(){}
}

?>
