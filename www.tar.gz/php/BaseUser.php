<?php
class BaseUser{
 /**
   BaseUser is a class used by the classes Model, View, but not Controller.
   Model class uses BaseUser to store the name of sidebar buttons.
   View class uses BaseUser to find which buttons to show using the attribute vector.
   Controller doesn't use BaseUser.
   BaseUser has an attribute vector which correspond to particular use case methods.
   This attribute vector should be based on a Authentication state.
   The Authentication state ultimately must lead to the identification of user types.
   User types are Patient, Nurse, Nurse Practitioner, Physician, Specialist, Admin, EMT, Technician.
   These user types can have other states that precede it.
   All states which double as user type are preceded by unknown-user state.
   BaseUser accepts 
 */
 

 private function Authenticate(){}
 private function SignUpNewUser(){}
 private function ScheduleAppointment(){}
 private function CancelAppointment(){}
 private function PrescribeMedication(){}
 private function WritePhysiciansExam(){}
 private function CreateDisease(){}
 private function ModifyDiseaseThread(){/**Modifies the symptom code*/}
 private function ViewMedicalRecord(){}
 private function ViewPrescription(){}
 private function ViewAccountBalance(){}
 private function MakePayment(){}
 private function ScheduleLabTest(){}
 private function ViewLabHistory(){}
 private function CreateSpecialistReferral(){}
 private function UpdateAccountInformation(){}
 private function CreateEmergencyFirstContact(){}
 private function WriteNursesNotes(){}
 
}

?>
